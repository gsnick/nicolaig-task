#!/usr/bin/env bash

/usr/bin/apt-get install parted
/sbin/parted /dev/sdb mklabel msdos
/sbin/parted /dev/sdb mkpart primary 1 100%
/sbin/mkfs.ext4 /dev/sdb1
/bin/mkdir -p /mnt/disk2
/bin/echo `blkid /dev/sdb1 | awk '{print$2}' | sed -e 's/"//g'`  /mnt/disk2   ext4   defaults 0   0 >> /etc/fstab
/bin/mount -a